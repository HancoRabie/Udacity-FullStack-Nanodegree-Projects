import fresh_tomatoes
import media

passionofthe_Christ = media.Movie("Passion of the Christ",
                                  "The life of Jesus Christ and the sacrifice He made for us displayed through film",
                                  "https://fupping.com/wp-content/uploads/2018/07/The-Passion-of-the-Christ-2004.jpg",
                                  "https://www.youtube.com/watch?v=MhdDIz3y9zo")

jaws = media.Movie("Jaws",
                   "A megaladon shark terrorizes the coast of Massachusetts",
                   "https://vignette.wikia.nocookie.net/jaws/images/d/da/Jaws-movie-poster.jpg/revision/latest?cb=20131015071208",
                   "https://www.youtube.com/watch?v=U1fu_sA7XhE")
 
ironman = media.Movie("Iron Man",
                      "The 2008 Iron Man film, featuring Robert Downey Jr.",
                      "https://mypostercollection.com/wp-content/uploads/2018/08/Iron-Man-Poster-2008-MyPosterCollection.com-3-667x1001.jpg?x49793",
                      "https://www.youtube.com/watch?v=bK_Y5LjSJ-Y")
 
theamazing_spiderman = media.Movie("The Amazing Spider-Man",
                                   "The 2012 Spider-Man film",
                                   "https://images-na.ssl-images-amazon.com/images/I/61TUX3ObSLL.jpg",
                                   "https://www.youtube.com/watch?v=atCfTRMyjGU")
 
batman_begins = media.Movie("Batman Begins",
                            "The 2005 Batman film",
                            "https://cdn.cinematerial.com/p/297x/lq2dvjme/batman-begins-movie-poster-md.jpg",
                            "https://www.youtube.com/watch?v=ceGXspGc2_4")
 
superman_returns = media.Movie("Superman Returns",
                               "The 2006 Superman film",
                               "https://upload.wikimedia.org/wikipedia/pt/5/59/Superman_Returns_poster.jpg",
                               "https://www.youtube.com/watch?v=v4IOoyrfi0s")

movies = [passionofthe_Christ, jaws, ironman, theamazing_spiderman, batman_begins, superman_returns]
fresh_tomatoes.open_movies_page(movies)
